// ======================================
// DNZY RP — Character Creator (CLIENT) — FINAL
// Michael House Interior + Stable Camera (Front View) + Rotate Character with RMB
// ✅ Karakter kameraya bakar (ters durmaz)
// ✅ Sağ tık basılı + mouse hareketi = karakter kendi etrafında döner
// ✅ Kamera sabit, sadece pointAt karakteri takip eder
// ======================================

let creatorCam = null;
let localPlayer = mp.players.local;
let charBrowser = null;

let currentGender = "ERKEK";
let currentBeard = 0;
let currentBeardColor = 0;
let currentBrows = 0;
let currentBrowColor = 0;
let currentEyeliner = 0;
let currentEyelinerColor = 0;

let currentEyeShadow = 0;
let currentEyeShadowColor = 0;
// UYUMLU ID LİSTELERİ
const maleTops = [1, 7, 10, 13, 22, 26, 31, 54, 94, 131];
const femaleTops = [1, 5, 7, 10, 11, 15, 25, 48, 57, 100];
const maleLegs = [1, 4, 10, 12, 22, 24];
const femaleLegs = [1, 3, 4, 6, 11, 15];
const maleShoes = [1, 6, 12, 14, 20];
const femaleShoes = [1, 5, 13, 19, 20];

// Michael House interior için güvenli koordinat
const MICHAEL_INT_POS = new mp.Vector3(-802.3, 175.0, 72.8);

// ------------------------------
// CAMERA TUNING (BURADAN AYARLA)
// ------------------------------
const CAM_TUNE = {
  body: { dist: 2.20, camH: 0.40, lookH: 0.22, fov: 36 },
  head: { dist: 0.95, camH: 0.52, lookH: 0.68, fov: 28 },
feet: { dist: 1.25, camH: 0.16, lookH: -0.70, fov: 26 },
};

let currentCamMode = "body"; // "body" | "head" | "feet"
let _lastRotTick = 0;

// --------------------------------------------------
// Helpers
// --------------------------------------------------

function loadSceneAt(pos) {
  mp.game.streaming.requestCollisionAtCoord(pos.x, pos.y, pos.z);
  mp.game.streaming.newLoadSceneStart(pos.x, pos.y, pos.z, pos.x, pos.y, pos.z, 60.0, 0);
  mp.game.streaming.newLoadSceneStartSphere(pos.x, pos.y, pos.z, 60.0, 0);
}

function ensureMichaelInterior() {
  mp.game.streaming.requestIpl("v_michael");
  mp.game.streaming.requestIpl("v_michael_garage");
  mp.game.streaming.requestIpl("v_michael_bed");
  mp.game.streaming.requestIpl("v_michael_lounge");
}

function setCreatorState(enabled) {

  mp.game.ui.displayRadar(!enabled);
  mp.gui.cursor.show(enabled, enabled);

  if (enabled) {
    localPlayer.freezePosition(true);
    localPlayer.setInvincible(true);
  } else {
    localPlayer.freezePosition(false);
    localPlayer.setInvincible(false);
  }
}

function createOrUpdateCam(camPos, lookPos, fov) {
  if (!creatorCam) {
    creatorCam = mp.cameras.new("default", camPos, new mp.Vector3(0, 0, 0), fov);
  }
  creatorCam.setCoord(camPos.x, camPos.y, camPos.z);
  creatorCam.pointAtCoord(lookPos.x, lookPos.y, lookPos.z);
  creatorCam.setFov(fov);
  creatorCam.setActive(true);
  mp.game.cam.renderScriptCams(true, false, 0, true, false);
}

function destroyCreatorCam() {
  if (!creatorCam) return;
  creatorCam.setActive(false);
  mp.game.cam.renderScriptCams(false, false, 0, true, false);
  creatorCam.destroy();
  creatorCam = null;
}

// Kamera: “Front view” (karakterin karşısından baksın)
// Not: heading’i facePlayerToCamera() belirleyecek, kamera sabit bir "ön" pozisyonda durur.
function applyFrontCamera(mode) {
  const t = CAM_TUNE[mode] || CAM_TUNE.body;
  const p = localPlayer.position;

  // Karakterin karşısı: Y ekseninde önden bakış (stable)
  const camPos = new mp.Vector3(p.x, p.y - t.dist, p.z + t.camH);
  const lookPos = new mp.Vector3(p.x, p.y, p.z + t.lookH);

  createOrUpdateCam(camPos, lookPos, t.fov);
  facePlayerToCamera();
}

// Karakteri kameraya döndür (ters durma fix)
function facePlayerToCamera() {
  if (!creatorCam) return;

  const camPos = creatorCam.getCoord(); // RageMP'de var
  const p = localPlayer.position;

  // Kameradan karaktere yön
  const dx = p.x - camPos.x;
  const dy = p.y - camPos.y;

  // heading hesapla
  const heading = (Math.atan2(dx, dy) * 180 / Math.PI + 180 + 360) % 360;
  localPlayer.setHeading(heading);
}

// Kameranın hedefi karakterde kalsın (rotate sırasında)
function updateCamLookToPlayer() {
  if (!creatorCam) return;
  const t = CAM_TUNE[currentCamMode] || CAM_TUNE.body;
  const p = localPlayer.position;
  creatorCam.pointAtCoord(p.x, p.y, p.z + t.lookH);
}

function applyDefaultClothesForGender() {
  const isMale = (currentGender === "ERKEK");

  const topId = isMale ? maleTops[0] : femaleTops[0];
  const legId = isMale ? maleLegs[0] : femaleLegs[0];
  const shoeId = isMale ? maleShoes[0] : femaleShoes[0];

  localPlayer.setComponentVariation(11, topId, 0, 0);
  localPlayer.setComponentVariation(4, legId, 0, 0);
  localPlayer.setComponentVariation(6, shoeId, 0, 0);
  localPlayer.setComponentVariation(8, 15, 0, 0);
}

// --------------------------------------------------
// START CREATOR
// --------------------------------------------------

mp.events.add("client:character:startCreator", () => {
  ensureMichaelInterior();
  loadSceneAt(MICHAEL_INT_POS);

  setTimeout(() => {
    localPlayer.position = MICHAEL_INT_POS;
    localPlayer.setAlpha(255);

    setCreatorState(true);
    applyDefaultClothesForGender();

    // Kamera + karakter yönü
    currentCamMode = "body";
    applyFrontCamera(currentCamMode);
	setTimeout(() => facePlayerToCamera(), 0);
setTimeout(() => facePlayerToCamera(), 150);

    // UI
    if (!charBrowser) {
      charBrowser = mp.browsers.new("package://character/ui/index.html");
    }
  }, 350);
});

// --------------------------------------------------
// ROTATE CHARACTER (RMB + MouseX)
// --------------------------------------------------

mp.events.add("render", () => {
    // Eğer kamera aktifse (creatorCam) veya spawn ekranı açıksa (spawnBrowser)
    if (creatorCam || spawnBrowser) {
        // Her karede mouse imlecini ve CEF odağını zorla aktif tutar
        mp.gui.cursor.show(true, true); 

        // Tüm oyun içi kontrolleri kapat (Karakterin yürümesini vs. engeller)
        mp.game.controls.disableAllControlActions(0);

        // Sadece gerekli kontrolleri aç (Mouse bakışı ve sağ tık)
        mp.game.controls.enableControlAction(0, 1, true);  // LOOK_LR
        mp.game.controls.enableControlAction(0, 2, true);  // LOOK_UD
        mp.game.controls.enableControlAction(0, 25, true); // RMB (Sağ Tık)

        const aiming = mp.game.controls.isControlPressed(0, 25);

        if (aiming) {
            // RMB basılıyken: karakteri oyuncu döndürür
            const mx = mp.game.controls.getDisabledControlNormal(0, 1);
            const newHeading = (localPlayer.getHeading() + mx * 140) % 360;
            localPlayer.setHeading(newHeading);
            updateCamLookToPlayer();
        } else {
            // RMB basılı değilken: karakter her zaman kameraya baksın
            facePlayerToCamera();
            updateCamLookToPlayer();
        }
    }
});

// ------------------------------
// UI -> CLIENT EVENTS
// ------------------------------

mp.events.add("client:char:setGender", (g) => {
  currentGender = g;

  const isMale = (g === "ERKEK");
  const model = isMale ? "mp_m_freemode_01" : "mp_f_freemode_01";

  // model değiştir
  mp.events.callRemote("server:character:changeModel", model);

  // UI'ye "gender değişti" de (sakal alanını kapat/aç)
  if (charBrowser) {
    charBrowser.execute(`window.__setGender && window.__setGender(${isMale ? `"ERKEK"` : `"KADIN"`});`);
  }

  setTimeout(() => {
    // ✅ Kadın preset
    if (!isMale) {
      // Anne 45, baba 34, karışım 0.5 (5/10)
      localPlayer.setHeadBlendData(45, 34, 0, 45, 34, 0, 0.5, 0.5, 0, false);

      // Saç modeli 15 + default saç rengi 0
      localPlayer.setComponentVariation(2, 15, 0, 0);
      localPlayer.setHairColor(0, 0);

      // ✅ Kadında sakalı tamamen kapat
      currentBeard = 0;
      currentBeardColor = 0;
      localPlayer.setHeadOverlay(1, 0, 0.0, 0, 0); // opacity 0

    } else {
      // ✅ Erkek seçilince reset (istersen burada farklı preset de atarız)
      localPlayer.setHeadBlendData(0, 0, 0, 0, 0, 0, 0.5, 0.5, 0, false);

      // Saç reset (istersen 0 kalsın)
      localPlayer.setComponentVariation(2, 0, 0, 0);
      localPlayer.setHairColor(0, 0);

      // ✅ Sakalı geri aç (model 0 ama aktif görünür olsun)
      currentBeard = 0;
      currentBeardColor = 0;
      localPlayer.setHeadOverlay(1, 0, 1.0, 0, 0); // opacity 1.0
    }

    // kıyafetleri tekrar giydir
    applyDefaultClothesForGender();

    // yüzü kameraya baktır
    facePlayerToCamera();
    setTimeout(() => facePlayerToCamera(), 150);
  }, 250);
});

mp.events.add("client:char:setHeritage", (m, d, s) => {
  localPlayer.setHeadBlendData(
    parseInt(m), parseInt(d), 0,
    parseInt(m), parseInt(d), 0,
    0.5, parseFloat(s) / 10, 0,
    false
  );
});

mp.events.add("client:char:setFaceFeature", (idx, val) => {
  localPlayer.setFaceFeature(parseInt(idx), parseFloat(val));
});

mp.events.add("client:char:updateFeature", (type, value) => {
  const val = parseInt(value);
  const isMale = (currentGender === "ERKEK");

  switch (type) {
    case "hair":
      localPlayer.setComponentVariation(2, val, 0, 0);
      break;

    case "hair_color":
      localPlayer.setHairColor(val, val);
      break;

    case "beard":
      currentBeard = val;
      localPlayer.setHeadOverlay(1, val, 1.0, currentBeardColor, 0);
      break;

    case "beard_color":
      currentBeardColor = val;
      localPlayer.setHeadOverlay(1, currentBeard, 1.0, currentBeardColor, 0);
      break;
	  
	case "brows":
  currentBrows = val;
  localPlayer.setHeadOverlay(2, val, 1.0, currentBrowColor, 0);
  break;

case "brows_color":
  currentBrowColor = val;
  // kaş overlay tekrar bas
  localPlayer.setHeadOverlay(2, currentBrows || 0, 1.0, currentBrowColor, 0);
  break;
  
  case "eyeliner":
  currentEyeliner = val;
  // ✅ Standart: 4 = Makeup overlay (çoğu build’de eyeliner/far burada)
  localPlayer.setHeadOverlay(4, currentEyeliner, 1.0, currentEyelinerColor, 0);
  break;

case "eyeliner_color":
  currentEyelinerColor = val;
  localPlayer.setHeadOverlay(4, currentEyeliner, 1.0, currentEyelinerColor, 0);
  break;

case "eyeshadow":
  currentEyeShadow = val;
  // ✅ Standart: 5 = Blush / 8 = Lipstick vs değişebilir, bazı paketlerde eyeshadow da 4’te olur
  // Bu yüzden eyeshadow’u şimdilik 4’ün “ayrı numarası” gibi kullanıyoruz:
  localPlayer.setHeadOverlay(4, currentEyeShadow, 1.0, currentEyeShadowColor, 0);
  break;

case "eyeshadow_color":
  currentEyeShadowColor = val;
  localPlayer.setHeadOverlay(4, currentEyeShadow, 1.0, currentEyeShadowColor, 0);
  break;

    case "eyes":
      localPlayer.setEyeColor(val);
      break;

    case "top": {
      const tId = isMale ? maleTops[val % maleTops.length] : femaleTops[val % femaleTops.length];
      localPlayer.setComponentVariation(11, tId, 0, 0);
      localPlayer.setComponentVariation(8, 15, 0, 0);
      break;
    }

    case "legs": {
      const lId = isMale ? maleLegs[val % maleLegs.length] : femaleLegs[val % femaleLegs.length];
      localPlayer.setComponentVariation(4, lId, 0, 0);
      break;
    }
	
	

    case "shoes": {
      const sId = isMale ? maleShoes[val % maleShoes.length] : femaleShoes[val % femaleShoes.length];
      localPlayer.setComponentVariation(6, sId, 0, 0);
      break;
    }
  }
});

// Kamera butonları (head/body/feet) — front view korunur
mp.events.add("client:char:setCamera", (t) => {
  if (!creatorCam) return;

  if (t === "head") currentCamMode = "head";
  else if (t === "feet") currentCamMode = "feet";
  else currentCamMode = "body";

  applyFrontCamera(currentCamMode);
});
// Bu satırı bul ve sil ya da yorum satırı yap:
// mp.gui.chat.push(`[CLIENT] callRemote save...`);
// Kayıt tetikleyicisi - GÜNCELLENDİ
// client/character/index.js

// client/character/index.js

// client/character/index.js - BU KISMI DÜZELT

mp.events.add("client:char:finish", (name, surname, age, gender, appDataJson) => {
    try {
        // Veritabanı ENUM uyumu
        const dbGender = (gender === "KADIN" || gender === "female") ? "female" : "male";

        mp.events.callRemote("server:character:save", 
            name, 
            surname, 
            parseInt(age), 
            dbGender, 
            appDataJson
        );
    } catch (e) {
        if (charBrowser) {
            charBrowser.execute(`console.error("Client Hatası: ${e.message}");`);
        }
    }
}); // <--- Bu parantezlerin eksik veya fazla olması hataya sebep oluyor!

// Sunucudan gelen kilit açma sinyali
mp.events.add("client:char:unlockUI", () => {
    if (charBrowser) {
        charBrowser.execute(`unlockCreateButton()`);
    }
});



let spawnBrowser = null;

mp.events.add("client:character:showSpawnMenu", (hasHouse, hasFamily) => {
    // 1. Önce karakter oluşturma arayüzünü ve kamerasını temizle
    if (charBrowser) {
        charBrowser.destroy();
        charBrowser = null;
    }
    destroyCreatorCam();
    
    // 2. Spawn ekranını aç
    spawnBrowser = mp.browsers.new("package://character/ui/spawn.html");
    
    // Mouse ve dondurma durumunu spawn ekranı için aktif tut
    mp.gui.cursor.show(true, true);
    localPlayer.freezePosition(true);

    // 3. spawn.html içindeki setOptions fonksiyonuna verileri gönder
    setTimeout(() => {
        if (spawnBrowser) {
            spawnBrowser.execute(`setOptions(${hasHouse}, ${hasFamily})`);
        }
    }, 500);
});

// Spawn ekranındaki butona basınca burası çalışır
// DOSYA: client_packages/character/index.js (EN ALT KISIM)

mp.events.add("client:character:selectSpawn", (type) => {
    if (spawnBrowser) {
        spawnBrowser.destroy();
        spawnBrowser = null;
    }
    
    setCreatorState(false); 
    localPlayer.freezePosition(false);
    mp.game.cam.renderScriptCams(false, false, 0, true, false);

    // --- BURASI KRİTİK ---
    // Eğer burası true ise siyah kutu geri gelir. FALSE olmalı!
    mp.gui.chat.show(false);      
    mp.gui.chat.activate(false);  
    // ---------------------
    
    mp.events.callRemote("server:character:spawnFinal", type);
})

mp.events.add("client:char:showError", (message) => {
    if (charBrowser) {
        // Hazırladığın showAlert fonksiyonunu tetikler
        charBrowser.execute(`showAlert("${message}")`);
    }
});
